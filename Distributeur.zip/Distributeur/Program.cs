﻿using System;
using System.Collections.Generic;
using System.IO;

class Program
{
    static void Main()
    {
        // Chemin du fichier pour stocker les numéros de tickets
        string filePath = Path.Combine(Path.GetTempPath(), "fnumero.txt");

        // Dictionnaire pour stocker les numéros de tickets pour chaque type d'opération
        Dictionary<string, int> ticketNumbers = LoadTicketNumbers(filePath);

        // Liste pour stocker les clients et leurs numéros de tickets
        List<string> clients = new List<string>();

        while (true)
        {
            Console.WriteLine("Bienvenue à la banque !");
            Console.WriteLine("Veuillez choisir le type d'opération :");
            Console.WriteLine("1. Versement");
            Console.WriteLine("2. Retrait");
            Console.WriteLine("3. Informations");
            Console.WriteLine("4. Quitter");

            string? choice = Console.ReadLine();

            if (choice == "4")
            {
                Console.WriteLine("Merci d'avoir utilisé notre service. Au revoir !");
                break;
            }

            string operationType = "";
            if (choice == "1")
            {
                operationType = "V";
            }
            else if (choice == "2")
            {
                operationType = "R";
            }
            else if (choice == "3")
            {
                operationType = "I";
            }
            else
            {
                Console.WriteLine("Choix invalide. Veuillez réessayer.");
                continue;
            }

            // Demander les informations du client
            Console.WriteLine("Veuillez entrer votre numéro de compte :");
            string? accountNumber = Console.ReadLine();
            Console.WriteLine("Veuillez entrer votre nom :");
            string? lastName = Console.ReadLine();
            Console.WriteLine("Veuillez entrer votre prénom :");
            string? firstName = Console.ReadLine();

            // Vérifier que les valeurs ne sont pas null avant de les utiliser
            if (accountNumber == null || lastName == null || firstName == null)
            {
                Console.WriteLine("Erreur : les informations du client ne peuvent pas être null.");
                continue;
            }

            // Incrémenter le numéro de ticket pour le type d'opération choisi
            ticketNumbers[operationType]++;
            string ticketNumber = $"{operationType}-{ticketNumbers[operationType]}";

            // Ajouter le client à la liste
            clients.Add($"{ticketNumber} - {lastName} {firstName} - Compte: {accountNumber}");

            // Afficher le numéro de ticket et le nombre de personnes en attente
            int waitingCount = ticketNumbers[operationType] - 1;
            Console.WriteLine($"Votre numéro est {ticketNumber}, et il y a {waitingCount} personnes qui attendent avant vous.");

            Console.WriteLine("Voulez-vous prendre un autre numéro ? (O/N)");
            string? anotherTicket = Console.ReadLine()?.ToUpper();
            if (anotherTicket != "O")
            {
                Console.WriteLine("Merci d'avoir utilisé notre service. Au revoir !");
                break;
            }
        }

        // Sauvegarder les numéros de tickets dans le fichier
        SaveTicketNumbers(filePath, ticketNumbers);

        // Afficher la liste des clients à la fin
        Console.WriteLine("\nListe des clients :");
        foreach (var client in clients)
        {
            Console.WriteLine(client);
        }
    }

    static Dictionary<string, int> LoadTicketNumbers(string filePath)
    {
        Dictionary<string, int> ticketNumbers = new Dictionary<string, int>
        {
            { "V", 0 }, // Versement
            { "R", 0 }, // Retrait
            { "I", 0 }  // Informations
        };

        if (File.Exists(filePath))
        {
            string[] lines = File.ReadAllLines(filePath);
            foreach (var line in lines)
            {
                string[] parts = line.Split('=');
                if (parts.Length == 2 && ticketNumbers.ContainsKey(parts[0]))
                {
                    ticketNumbers[parts[0]] = int.Parse(parts[1]);
                }
            }
        }

        return ticketNumbers;
    }

    static void SaveTicketNumbers(string filePath, Dictionary<string, int> ticketNumbers)
    {
        List<string> lines = new List<string>();
        foreach (var kvp in ticketNumbers)
        {
            lines.Add($"{kvp.Key}={kvp.Value}");
        }
        File.WriteAllLines(filePath, lines);
    }
}